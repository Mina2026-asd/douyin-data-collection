#!/usr/bin/env python3
"""
Cookie 提取脚本 —— 在你自己电脑上运行一次即可

功能：
  1. 打开 Chromium 浏览器，跳转到抖音登录页
  2. 你用抖音 App 扫码登录
  3. 登录成功后自动提取 Cookie 保存为 JSON
  4. 把 JSON 内容复制到 GitHub Secrets 即可

使用方法：
  pip install playwright
  playwright install chromium
  python setup_cookie.py
"""

import json
import sys
from playwright.sync_api import sync_playwright

OUTPUT_FILE = "douyin_cookies.json"


def main():
    print("=" * 60)
    print("抖音 Cookie 提取工具")
    print("=" * 60)
    print()
    print("即将打开浏览器，请准备好抖音 App 扫码...")
    print()

    with sync_playwright() as p:
        # 启动浏览器（非无头模式，需要看到二维码）
        browser = p.chromium.launch(
            headless=False,
            args=[
                "--disable-blink-features=AutomationControlled",
            ],
        )
        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 800},
        )
        page = context.new_page()

        # 跳转到抖音首页
        print("→ 正在打开抖音...")
        page.goto("https://www.douyin.com/", wait_until="domcontentloaded", timeout=30000)

        # 等待用户扫码登录（最多等 120 秒）
        print("→ 请用抖音 App 扫描浏览器中的二维码...")
        print("  （等待最多 120 秒）")
        try:
            page.wait_for_url(
                "https://www.douyin.com/?recommend=1*",
                timeout=120000,
            )
            print("✓ 登录成功！")
        except Exception:
            # 即使超时，也尝试看看有没有 cookie
            print("⚠ 等待超时，尝试检查登录状态...")
            page.wait_for_timeout(3000)

        # 检查是否真正登录（看页面有没有用户信息）
        try:
            # 等待用户头像出现作为登录标志
            page.wait_for_selector('[data-e2e="user-avatar"]', timeout=5000)
            print("✓ 确认已登录")
        except Exception:
            print("⚠ 无法确认登录状态，但继续提取 Cookie...")

        # 提取所有 Cookie
        cookies = context.cookies()
        # 只保留关键域名
        key_cookies = [c for c in cookies if "douyin.com" in c.get("domain", "")]

        if not key_cookies:
            print("✗ 未提取到抖音 Cookie！请确认已登录后再试。")
            browser.close()
            sys.exit(1)

        # 保存到文件
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            json.dump(key_cookies, f, ensure_ascii=False, indent=2)

        print(f"✓ 已提取 {len(key_cookies)} 个 Cookie，保存到 {OUTPUT_FILE}")
        print()

        # 输出关键 Cookie 概览
        important_names = [
            "sessionid", "passport_csrf_token", "sid_guard",
            "uid_tt", "sid_tt", "sso_uid_tt", "sso_sid_tt",
        ]
        found = [c["name"] for c in key_cookies if c["name"] in important_names]
        print(f"关键 Cookie: {found}")
        if "sessionid" not in found:
            print("⚠ 警告：未找到 sessionid，可能采集会失败！")
        print()

        browser.close()

    # 打印下一步操作
    print("=" * 60)
    print("✅ Cookie 提取完成！下一步：")
    print()
    print("1. 打开 GitHub 仓库 → Settings → Secrets and variables → Actions")
    print("2. 点击 New repository secret")
    print("3. Name 填: DOUYIN_COOKIES")
    print("4. Secret 填: 把下面整个 JSON 内容复制进去")
    print()
    print("--- 复制以下全部内容 ---")
    with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
        print(f.read())
    print("--- 复制以上全部内容 ---")
    print()
    print("⚠ Cookie 有效期约 7-30 天，过期后需要重新运行本脚本提取。")


if __name__ == "__main__":
    main()
# 抖音数据采集 → 飞书多维表（GitHub Actions 版）

每天自动采集 3 个抖音账号（记忆星球、麦猫、高山流水）的最新视频互动数据，写入飞书多维表。

## 架构

```
[GitHub Actions 定时触发] → [Playwright 采集抖音数据] → [飞书 Open API 写入多维表]
     每天 9:00 + 18:30          无需浏览器，纯 API 调用          按视频链接去重
```

## 快速开始（3 步）

### 第 1 步：创建 GitHub 仓库

```bash
# 把本目录上传到 GitHub
git init
git add .
git commit -m "抖音数据采集"
git remote add origin https://github.com/你的用户名/仓库名.git
git push -u origin main
```

### 第 2 步：配置 3 个 GitHub Secrets

进入仓库 → **Settings → Secrets and variables → Actions → New repository secret**，依次添加：

| Secret 名称 | 值 | 如何获取 |
|---|---|---|
| `DOUYIN_COOKIES` | Cookie JSON 数组 | 见下方「获取 Cookie」 |
| `FEISHU_APP_ID` | 飞书应用 App ID | 见下方「创建飞书应用」 |
| `FEISHU_APP_SECRET` | 飞书应用 App Secret | 见下方「创建飞书应用」 |

### 第 3 步：手动触发测试

进入仓库 → **Actions → 抖音数据采集 → Run workflow**，手动触发一次，验证流程。

---

## 获取 Cookie

在你自己电脑上运行一次：

```bash
pip install playwright
playwright install chromium
python scripts/setup_cookie.py
```

浏览器会打开抖音登录页，用抖音 App 扫码登录后，脚本自动输出 Cookie JSON。把整个 JSON 复制到 GitHub Secrets 的 `DOUYIN_COOKIES`。

> ⚠️ Cookie 有效期约 7-30 天，过期后需要重新运行提取。

---

## 创建飞书应用

### 1. 创建应用

打开 [飞书开发者后台](https://open.feishu.cn/app)，点击「创建企业自建应用」：
- 应用名称：抖音数据采集
- 应用图标：随意

### 2. 添加权限

进入应用 → **权限管理**，搜索并添加以下权限：
- `bitable:app`（多维表格）

### 3. 发布应用

进入应用 → **版本管理与发布** → 创建版本 → 发布（仅企业内部可用即可）。

### 4. 获取凭证

进入应用 → **凭证与基础信息**，复制：
- `App ID` → 填入 `FEISHU_APP_ID`
- `App Secret` → 填入 `FEISHU_APP_SECRET`

### 5. 授权多维表格

打开你的多维表格 → 右上角 `...` → **更多** → **添加文档应用** → 搜索「抖音数据采集」→ 添加。

---

## 定时触发

工作流已配置每天两次自动执行：

| 触发时间 | UTC Cron | 说明 |
|---------|----------|------|
| 每天 09:00 | `0 1 * * *` | 上午采集 |
| 每天 18:30 | `30 10 * * *` | 下午采集 |

修改时间编辑 `.github/workflows/collect.yml` 中的 `cron` 字段即可。

---

## 手动执行

1. 进入仓库 → Actions
2. 选择「抖音数据采集」
3. 点击「Run workflow」
4. 查看运行日志

---

## 采集结果

每次运行后：
- 采集结果会保存为 GitHub Actions Artifact（保留 7 天）
- 数据自动写入飞书多维表：[抖音数据](https://maiyamedia.feishu.cn/base/USO1bXpU1a9pScsRhrgchbc5n9g)

---

## 账号列表

| 账号名 | 抖音号 | 主页链接 |
|--------|--------|----------|
| 记忆星球 | 30547611923 | [链接](https://v.douyin.com/ax-s3is_kDw/) |
| 麦猫 | 37681695466 | [链接](https://v.douyin.com/HioYfjG4r9A/) |
| 高山流水 | 50448224245 | [链接](https://v.douyin.com/eqbIesk6t5w/) |

---

## 常见问题

**Q: Cookie 过期了怎么办？**
A: 重新运行 `python scripts/setup_cookie.py`，把新的 JSON 更新到 GitHub Secrets。

**Q: 采集失败怎么办？**
A: 进入 Actions → 点击失败的运行 → 查看日志。常见原因：Cookie 过期、抖音 API 风控、网络问题。

**Q: 需要付费吗？**
A: GitHub Actions 免费额度每月 2000 分钟，本任务每次约 1 分钟，完全免费。飞书 API 也免费。